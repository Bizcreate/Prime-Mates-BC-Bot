//* Import the functions you need from the SDKs you need
import { initializeApp, getApps } from 'firebase/app';
import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';

//* Add the Web App's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCtlyW8_lljCZmU44soxgkBE_d8HGCPfcw",
  authDomain: "fir-99908.firebaseapp.com",
  projectId: "fir-99908",
  storageBucket: "fir-99908.firebasestorage.app",
  messagingSenderId: "923432102646",
  appId: "1:923432102646:web:225e44f6d5280e46d0dad7",
  measurementId: "G-L00B9GT053"
};

//* Initialize Firebase
let firebase_app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

//* Initialize Firebase Auth and set persistence
const auth = getAuth(firebase_app);
setPersistence(auth, browserLocalPersistence)
  .then(() => {
    console.log("Session persistence set to LOCAL");
  })
  .catch((error) => {
    console.error("Failed to set session persistence:", error);
  });

export { auth };
export default firebase_app;
